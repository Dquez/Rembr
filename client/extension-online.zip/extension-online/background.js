chrome.browserAction.setBadgeText({
  text: "ON"
});

// chrome.runtime.onMessage.addListener(function (msg, _, sendResponse) {
//   if (msg.message == "article") {
//     // var xhr = new XMLHttpRequest();
//     // xhr.open("GET", "http://localhost:3000/login", true);
//     // xhr.onreadystatechange = function () {
//     //   if (xhr.readyState == 4) {
//     //     // JSON.parse does not evaluate the attacker's scripts.
//     //     var resp = JSON.parse(xhr.responseText);
//     //     console.log(resp);
//     //     sendResponse(resp);
//     //   }
//     // }
//     // xhr.send();


//   }
// });



